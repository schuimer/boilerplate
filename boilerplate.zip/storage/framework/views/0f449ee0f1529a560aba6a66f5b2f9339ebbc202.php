<?php $model = app('\Modules\Channel\Entities\Channel'); ?>



<?php $__env->startSection('title', __('Update Channel')); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.forms.patch','data' => ['action' => route('Channel.update', $channel->id)]]); ?>
<?php $component->withName('forms.patch'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('Channel.update', $channel->id))]); ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.card','data' => []]); ?>
<?php $component->withName('backend.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('header'); ?> 
                <?php echo app('translator')->get('Update Channel'); ?>
             <?php $__env->endSlot(); ?>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
             <?php $__env->slot('headerActions'); ?> 
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.utils.link','data' => ['class' => 'card-header-action','href' => route('Channel'),'text' => __('Cancel')]]); ?>
<?php $component->withName('utils.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'card-header-action','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('Channel')),'text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Cancel'))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
             <?php $__env->endSlot(); ?>

             <?php $__env->slot('body'); ?> 
                <div>
                    <div class="form-group row">
                        <label for="name" class="col-md-2 col-form-label"><?php echo app('translator')->get('Channel Name'); ?></label>

                        <div class="col-md-10">
                            <input type="text"  name="name" class="form-control" placeholder="<?php echo e(__('Channel Name')); ?>" value="<?php echo e(old('name') ?? $channel->name); ?>" maxlength="100" required />
                        </div>
                    </div><!--form-group-->
                    <div class="form-group row">
                    <small class="float-right text-muted">
                    <strong style="margin-left: 15px;"><?php echo app('translator')->get('Channel Created On'); ?>:</strong> <?php echo e(date("jS F , Y H:i A", strtotime($channel->created_at))); ?>

                    <br>
                    <strong style="margin-left: 15px;"><?php echo app('translator')->get('Last updated On'); ?>:</strong> <?php echo e(date("jS F , Y H:i A", strtotime($channel->updated_at))); ?>

                    <small>
                    </div>
                </div>
             <?php $__env->endSlot(); ?>

             <?php $__env->slot('footer'); ?> 
                <button class="btn btn-sm btn-primary float-right" type="submit"><?php echo app('translator')->get('Update Channel'); ?></button>
             <?php $__env->endSlot(); ?>
            
         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\boilerplate\Modules/Channel\Resources/views/edit.blade.php ENDPATH**/ ?>