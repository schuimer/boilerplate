    <x-utils.view-button :href="route('admin.currency.show', $id)" />
    <x-utils.edit-button :href="route('admin.currency.edit', $id)" />
    <x-utils.delete-button :href="route('admin.currency.destroy', $id)" />