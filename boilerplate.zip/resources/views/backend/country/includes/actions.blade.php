    <x-utils.view-button :href="route('admin.country.show', $id)" />
    <x-utils.edit-button :href="route('admin.country.edit', $id)" />
    <x-utils.delete-button :href="route('admin.country.destroy', $id)" />
