<?php

namespace Modules\Channel\Http\Livewire\Rule;

use Livewire\Component;

class FormComponent extends Component
{
    public function render()
    {
        return view('channel::livewire.table');
    }
}