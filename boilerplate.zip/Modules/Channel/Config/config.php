<?php

return [
    'name' => 'Channel'
];
