    <x-utils.view-button :href="route('Channel.show', $id)" />
    <x-utils.edit-button :href="route('Channel.edit', $id)" />
    <x-utils.delete-button :href="route('Channel.destroy', $id)" />
    