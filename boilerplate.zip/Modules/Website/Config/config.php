<?php

return [
    'name' => 'Website'
];
