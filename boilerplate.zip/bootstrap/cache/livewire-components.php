<?php return array (
  'backend.channels-table' => 'App\\Http\\Livewire\\Backend\\ChannelsTable',
  'backend.countries-table' => 'App\\Http\\Livewire\\Backend\\CountriesTable',
  'backend.currencies-table' => 'App\\Http\\Livewire\\Backend\\CurrenciesTable',
  'backend.roles-table' => 'App\\Http\\Livewire\\Backend\\RolesTable',
  'backend.users-table' => 'App\\Http\\Livewire\\Backend\\UsersTable',
  'backend.websites-table' => 'App\\Http\\Livewire\\Backend\\WebsitesTable',
  'frontend.two-factor-authentication' => 'App\\Http\\Livewire\\Frontend\\TwoFactorAuthentication',
);