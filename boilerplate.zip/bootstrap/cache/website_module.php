<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Website\\Providers\\WebsiteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Website\\Providers\\WebsiteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);